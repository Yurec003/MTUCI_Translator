from flask import Flask, render_template, request
from translate import Translator

app = Flask(__name__)

translator_en_ru = Translator(from_lang='English', to_lang='Russian')
translator_ru_en = Translator(from_lang='Russian', to_lang='English')


@app.route('/', methods=['GET', 'POST'])
def dict_page():
    if request.method == 'POST':
        word = request.form["word"]
        lang = request.form["lang"]
        if lang == 'RU':
            w = translator_en_ru.translate(word)
        else:
            if lang == 'EN':
                w = translator_ru_en.translate(word)
        return render_template('result.html', word=w)

    return render_template('dict.html')


if __name__ == '__main__':
    app.run()
